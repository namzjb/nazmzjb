//base by DGXeon
//recode by rizal-developer 
/// script gratis jangan di jual 😹
//*List panel privat*
//• ∞/unlimited = Rp.8.000 

//order  langsung pv : wa.me/6283191296807
//order2  langsung pv : wa.me/6283134463914
//tele : t.me/LenzzSence
//info : https://whatsapp.com/channel/0029VawTuv09Gv7VHSUvYi37



const fs = require('fs')
const chalk = require('chalk')

//owmner v card
global.ytname = "zal_x_u" //ur yt chanel name
global.socialm = "i dont have" //ur github or insta name
global.location = "singapore" //ur location

//new
global.botname = '𝗮𝗺𝗯𝗮𝘁𝘂𝗯𝗼𝘁' //ur bot name
global.ownernumber = '6283191296807' //ur owner number
global.ownername = 'rizal-dev' //ur owner name
global.websitex = "https://whatsapp.com/channel/0029VawTuv09Gv7VHSUvYi37"
global.wagc = "https://chat.whatsapp.com/CAwshQbAvddBHlYLlPBubo"
global.themeemoji = '🪀'
global.wm = "rizal-dev"
global.botscript = 'https://www.youtube.com/@zal_x_u' //script link
global.packname = "𝗮𝗺𝗯𝗮𝘁𝘂𝗯𝗼𝘁"
global.author = "rizal-developer"
global.creator = "6283191296807@s.whatsapp.net"
global.xprefix = '.'
global.premium = ["6283191296807"] // Premium User
global.hituet = 0

//bot sett
global.typemenu = 'v8' // menu type 'v1' => 'v8'
global.typereply = 'v2' // reply type 'v1' => 'v3'
global.autoblocknumber = '' //set autoblock country code
global.antiforeignnumber = '' //set anti foreign number country code
global.welcome = true //welcome/left in groups
global.anticall = false //bot blocks user when called
global.autoswview = true //auto status/story view
global.adminevent = false //show promote/demote message
global.groupevent = false //show update messages in group chat
//msg
global.mess = {
	limit: 'Batas Anda telah habis!',
	nsfw: 'Nsfw dinonaktifkan di grup ini, Harap beri tahu admin untuk mengaktifkannya',
    done: 'Done✓',
    error: 'Error!',
    success: 'Succes'
}
//thumbnail
global.thumb = fs.readFileSync('./XeonMedia/theme/cheemspic.jpg')

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update'${__filename}'`))
    delete require.cache[file]
    require(file)
})